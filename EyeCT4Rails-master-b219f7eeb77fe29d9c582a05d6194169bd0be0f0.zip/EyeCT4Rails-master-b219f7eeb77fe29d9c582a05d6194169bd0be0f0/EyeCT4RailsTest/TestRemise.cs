﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EyeCT4RailsBackend;

namespace EyeCT4RailsTest
{
	[TestClass]
	public class TestRemise
	{

	}
}
